﻿using System;

class QuotesInStrings
{
    static void Main()
    {
        Console.WriteLine("The \"se\" of quotations causes difficultie.");
        string quoted = @"The ""use"" of quatations causes difficultes";
        Console.WriteLine(quoted);

    }
}

