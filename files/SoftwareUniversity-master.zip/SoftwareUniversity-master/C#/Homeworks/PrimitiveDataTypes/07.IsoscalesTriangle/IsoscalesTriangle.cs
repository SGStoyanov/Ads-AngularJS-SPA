﻿using System;
using System.Text;

class IsoscalesTriangle
{
    static void Main()
    {
        char symbol = '\u00a9';     
        Console.WriteLine(@"     {0}
{0}      
{0}     {0}
  {0} {0} {0} {0}",symbol);

    }
}

