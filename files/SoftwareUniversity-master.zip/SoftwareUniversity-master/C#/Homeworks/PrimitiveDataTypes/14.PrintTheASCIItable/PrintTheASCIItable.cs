﻿using System;

class PrintTheASCIItable
{
    static void Main()
    {
        for (int i = 3; i <7; i++)
        {
            Console.Write("{0} ", (char)i);
            
        }

    }
}

