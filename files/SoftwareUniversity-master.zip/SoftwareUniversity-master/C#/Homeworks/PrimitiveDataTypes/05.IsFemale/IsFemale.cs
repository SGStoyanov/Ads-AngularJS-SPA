﻿using System;

class IsFemale
{
    static void Main()
    {
        bool isFemale = false;
        Console.WriteLine("Borislav is a female:{0}",isFemale);

    }
}

