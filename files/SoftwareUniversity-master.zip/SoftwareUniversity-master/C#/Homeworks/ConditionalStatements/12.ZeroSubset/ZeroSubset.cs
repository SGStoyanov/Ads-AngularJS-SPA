﻿using System;

class ZeroSubset
{
    static void Main()
    {

    }
}

