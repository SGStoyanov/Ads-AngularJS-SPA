import java.time.LocalDateTime;
public class CurrentDateTime {

	public static void main(String[] args) {
		LocalDateTime today = LocalDateTime.now();
		System.out.println(today);
       
	}

}
