﻿namespace Customer
{
    public enum CustomerType
    {
        OneTime,
        Regular,
        Golden,
        Diamond,
    }
}
