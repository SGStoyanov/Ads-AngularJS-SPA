﻿
namespace Geometry.Geometry2D
{
    using System;

    class Point2D
    {
    }
}
