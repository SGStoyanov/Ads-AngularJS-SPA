﻿
namespace Geometry.Geometry2D
{
    using System;

    class Figure2D
    {
    }
}
