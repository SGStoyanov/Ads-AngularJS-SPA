﻿
namespace Geometry.Geometry2D
{
    using System;

    class Circle
    {
    }
}
