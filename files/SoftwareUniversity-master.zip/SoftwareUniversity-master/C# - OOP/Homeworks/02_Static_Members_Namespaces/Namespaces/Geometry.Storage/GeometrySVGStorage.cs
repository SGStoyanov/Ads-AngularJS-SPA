﻿
namespace Geometry.Storage
{
    using System;

    class GeometrySVGStorage
    {
    }
}
