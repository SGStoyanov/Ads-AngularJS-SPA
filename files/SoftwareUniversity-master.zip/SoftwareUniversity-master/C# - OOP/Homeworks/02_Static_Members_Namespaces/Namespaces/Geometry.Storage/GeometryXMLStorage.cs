﻿
namespace Geometry.Storage
{
    using System;

    class GeometryXMLStorage
    {
    }
}
