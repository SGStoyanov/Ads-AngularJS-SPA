﻿
namespace Geometry.UI
{
    using System;

    class Screen3D
    {
    }
}
