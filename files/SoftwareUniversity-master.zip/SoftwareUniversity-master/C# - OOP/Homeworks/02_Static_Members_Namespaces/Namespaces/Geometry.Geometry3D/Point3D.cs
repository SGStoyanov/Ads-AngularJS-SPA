﻿
namespace Geometry.Geometry3D
{
    using System;

    class Point3D
    {
    }
}
