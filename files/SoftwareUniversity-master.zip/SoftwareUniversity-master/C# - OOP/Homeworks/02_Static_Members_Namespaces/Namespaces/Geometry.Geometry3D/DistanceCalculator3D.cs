﻿
namespace Geometry.Geometry3D
{
    using System;

    class DistanceCalculator3D
    {
    }
}
