﻿
namespace Geometry.Geometry3D
{
    using System;
    class Path3D
    {
    }
}
