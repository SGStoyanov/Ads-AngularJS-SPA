﻿
namespace StudentApp
{
    public enum GroupName
    {
        Sofia = 2,
        Plovdiv = 1,
        Varna = 3,
    }
}
