package Shop.PurchaseManagerExceptions;

public class PurchaseManagerException extends Exception{
	public PurchaseManagerException(String message){
		super(message);
	}

}
