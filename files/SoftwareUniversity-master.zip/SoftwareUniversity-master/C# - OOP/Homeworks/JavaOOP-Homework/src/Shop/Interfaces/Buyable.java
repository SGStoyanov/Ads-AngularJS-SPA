package Shop.Interfaces;

public interface Buyable {
   public double getPrice();
}
