package Shop;

public enum AgeRestriction {
	NONE, TEENAGER, ADULT
}
