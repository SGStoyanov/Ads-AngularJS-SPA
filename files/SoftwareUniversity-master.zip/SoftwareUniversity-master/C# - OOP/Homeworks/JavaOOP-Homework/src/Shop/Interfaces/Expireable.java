package Shop.Interfaces;

import java.util.Date;

public interface Expireable {
   public Date getExpirationDate();
}
