package Geometry.Interfaces;

public interface PerimeterMeasurable {
	double getPerimeter();
}
