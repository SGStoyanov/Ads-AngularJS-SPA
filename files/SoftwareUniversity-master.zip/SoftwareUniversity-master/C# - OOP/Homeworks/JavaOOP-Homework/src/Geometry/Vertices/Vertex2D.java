package Geometry.Vertices;

public class Vertex2D extends Vertex {
	public Vertex2D(double x, double y) {
		super(x, y);
	}
}
