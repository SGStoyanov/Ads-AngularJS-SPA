﻿
namespace Animals
{
    // define an interface ISound for implementing sounds
    public interface ISound
    {
        string ProduceSound();
    }
}
