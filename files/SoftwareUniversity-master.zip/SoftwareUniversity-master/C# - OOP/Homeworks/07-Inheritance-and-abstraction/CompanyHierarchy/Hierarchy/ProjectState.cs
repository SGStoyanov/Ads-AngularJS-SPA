﻿
namespace CompanyHierarchy.Hierarchy
{
    public enum ProjectState
    {
        Open,
        Closed,
    }
}
