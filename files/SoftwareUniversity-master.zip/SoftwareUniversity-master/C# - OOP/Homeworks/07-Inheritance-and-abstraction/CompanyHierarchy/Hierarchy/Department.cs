﻿
namespace CompanyHierarchy.Hierarchy
{
    public enum Department
    {
        Marketing,
        Sales,
        Accounting,
        Production,
    }
}
