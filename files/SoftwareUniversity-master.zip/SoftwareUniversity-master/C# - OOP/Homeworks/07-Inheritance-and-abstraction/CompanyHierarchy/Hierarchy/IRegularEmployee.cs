﻿
namespace CompanyHierarchy.Hierarchy
{
    public interface IRegularEmployee : IEmployee
    {
    }
}
