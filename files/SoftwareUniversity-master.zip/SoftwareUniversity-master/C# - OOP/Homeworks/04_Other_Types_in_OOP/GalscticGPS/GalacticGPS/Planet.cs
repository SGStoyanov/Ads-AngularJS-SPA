﻿
namespace GalscticGPS
{
    // define a public enum Planet
    public enum Planet
    {
        Mercury,
        Venus,
        Earth,
        Mars,
        Jupiter,
        Saturn,
        Uranus,
        Neptune
    }
}
