﻿namespace Shape.Shapes
{
    public interface IShape
    {
        double CalculateArea();
        double CalculatePermeter();
    }
}
