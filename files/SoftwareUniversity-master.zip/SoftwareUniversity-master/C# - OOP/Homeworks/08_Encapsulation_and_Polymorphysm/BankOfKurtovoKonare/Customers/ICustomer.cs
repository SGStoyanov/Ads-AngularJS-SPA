﻿namespace BankOfKurtovoKonare.Customers
{
    public interface ICustomer
    {
        string Name { get;}
        int ID { get;}
    }
}
