var app = angular.module('studentPage', []);


