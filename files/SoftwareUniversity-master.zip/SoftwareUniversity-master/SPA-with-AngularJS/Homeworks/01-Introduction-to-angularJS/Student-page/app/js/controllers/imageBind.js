app.controller('ImageBindController', function($scope){
      
});