var ctx = document.getElementById("myCanvas");
var ctx = ctx.getContext("2d");
ctx.font = "40px Arial";
ctx.textAlign = "center";
ctx.fillText("I love JavaScript", 200, 50);
ctx.fillStyle = "#E6B800";
ctx.fillRect(100, 150, 200, 200);
ctx.font = "bold 110px Arial";
ctx.fillStyle = "#0033CC";
ctx.fillText("JS", 230, 330);


