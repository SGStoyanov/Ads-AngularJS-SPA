'use strict';

app.controller('SampleDirectiveController', function ($scope) {
	
})