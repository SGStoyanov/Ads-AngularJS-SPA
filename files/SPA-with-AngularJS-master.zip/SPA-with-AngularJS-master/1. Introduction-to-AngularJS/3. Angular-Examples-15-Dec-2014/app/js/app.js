var app = angular.module('softUniApp', []);
