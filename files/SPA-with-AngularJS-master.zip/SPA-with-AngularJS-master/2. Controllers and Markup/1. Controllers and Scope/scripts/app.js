'use strict';

var app = angular.module('myApp', []);