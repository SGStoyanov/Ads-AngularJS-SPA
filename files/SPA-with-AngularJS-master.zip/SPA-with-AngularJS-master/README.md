SPA-with-AngularJS
==================

Repository for the JavaScript Applications course @ SoftUni: https://softuni.bg/courses/spa-applications-angularjs/