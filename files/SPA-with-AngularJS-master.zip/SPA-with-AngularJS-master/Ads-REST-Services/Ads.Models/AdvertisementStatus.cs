﻿namespace Ads.Models
{
    public enum AdvertisementStatus
    {
        Inactive,
        WaitingApproval,
        Published,
        Rejected
    }
}
