app.controller('ExceptionController', function ExceptionController($scope) {
	throw { message: 'Hvyrlqm greshka!' };
});