app.factory('appCache', function ($cacheFactory) {
	return $cacheFactory('appCache');
})