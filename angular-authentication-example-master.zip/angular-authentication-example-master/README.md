angular-authentication-example
==============================

AngularJS Basic HTTP Authentication Example

To see a demo and further details go to http://jasonwatmore.com/post/2014/05/26/AngularJS-Basic-HTTP-Authentication-Example.aspx
